#ifndef BLE_MIDI_H
#define BLE_MIDI_H

#include "utility/BLEMidiServer.h"
#include "utility/BLEMidiClient.h"

#endif